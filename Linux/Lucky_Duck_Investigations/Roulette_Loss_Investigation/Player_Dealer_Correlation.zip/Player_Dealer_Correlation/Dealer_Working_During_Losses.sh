#!/bin/bash
awk '{print $1, $2, $5, $6}' Dealer_schedule > Dealers_working_during_Losses


