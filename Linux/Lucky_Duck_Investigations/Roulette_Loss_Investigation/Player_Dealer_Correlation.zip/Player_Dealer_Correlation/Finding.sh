#1/bin/bash
I found that all the time there was a loss both Billy Jones and Mylie Schmidt were working.
